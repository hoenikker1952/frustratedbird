package cpreyt;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g3d.particles.influencers.ColorInfluencer;
import com.badlogic.gdx.graphics.g3d.particles.influencers.ParticleControllerInfluencer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class Truba {

    public static final int FLUCT=130;
    public static final int TUBE =100;
    public static final int LOWOPEN=120;
    public static final int TRUBAWID=52;

    private Texture verh, niz;
    private Vector2 posverh, posniz;
    private ParticleControllerInfluencer.Random ran;
    private Rectangle bverh, bniz;

    public Texture getVerh () {
        return verh;
    }

    public Texture getNiz () {
        return niz;
    }

    public Vector2 getPosverh () {
        return posverh;
    }

    public Vector2 getPosniz () {
        return posniz;
    }

    public Truba(float x) {
        verh = new Texture("vverh.png");
        niz = new Texture("niz.png");
        ran = new ParticleControllerInfluencer.Random();
        posverh = new Vector2(x, ran.nextInt(FLUCT) + TUBE + LOWOPEN);
        posniz = new Vector2(x, posverh.y - TUBE - niz.getHeight());

        bverh = new Rectangle(posverh.x, posverh.y, verh.getWidth(), verh.getHeight());
        bniz = new Rectangle(posniz.x, posniz.y, niz.getWidth(), niz.getHeight());

    }
    public void reposition(float x){
        posverh.set(x, ran.nextInt(FLUCT) + TUBE + LOWOPEN);
        posniz.set(x, posverh.y - TUBE - niz.getHeight());
        bverh.setPosition(posverh.x,posverh.y);
        bniz.setPosition(posniz.x,posniz.y);

    }

    public boolean collides(Rectangle player){
        return player.overlaps(bverh) || player.overlaps(bniz);

    }

}
