package cpreyt;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;

public class Fbird {
    private static final int MOVE = 100;
    private static final int GRAV = -14;
    private Vector3 posit;
    private Vector3 velos;
    private Rectangle bbird;

    private Texture bird;

    public Fbird(int x, int y){
        posit = new Vector3();
        velos = new Vector3();
        bird = new Texture("bird.png");
        bbird = new Rectangle(x, y, bird.getWidth(), bird.getHeight());
    }

    public Vector3 getPosit() {
        return posit;
    }

    public Texture getBird() {
        return bird;
    }

    public void update(float dt){
        if (posit.y>0)
            velos.add(0, GRAV, 0);
        velos.scl(dt);
        posit.add(MOVE*dt, velos.y, 0);
        if (posit.y<0)
            posit.y=0;

        velos.scl(1/dt);
        bbird.setPosition(posit.x, posit.y);

    }
    public void pryg(){

        velos.y=240;
    }
    public Rectangle getBbird(){
        return bbird;
    }

}
