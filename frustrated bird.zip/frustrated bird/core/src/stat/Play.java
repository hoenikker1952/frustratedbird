package stat;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.mygdx.game.Frustratedbird;

import cpreyt.Fbird;
import cpreyt.Truba;

public class Play extends State {

    public static final int SPACE = 124;
    public static final int COUNT = 5;

    private Fbird bird;
    private Texture background;

    private Array<Truba> trubi;

    public Play(GameStateManager gsm) {
        super(gsm);
        bird = new Fbird(50, 300);
        camera.setToOrtho(false, Frustratedbird.WIDTH/2, Frustratedbird.HEIGHT/2);
        background = new Texture("background.png");

        trubi = new Array<Truba>();

        for (int i=0; i<COUNT; i++){
            trubi.add(new Truba(i*(SPACE + Truba.TRUBAWID)));
        }


    }
    @java.lang.Override
    protected void handleInput() {
        if (Gdx.input.justTouched())
            bird.pryg();

    }

    @java.lang.Override
    public void update(float dt) {
        handleInput();
        bird.update(dt);
        camera.position.x=bird.getPosit().x+80;

        for (Truba truba: trubi){
            if (camera.position.x - (camera.viewportWidth/2)>truba.getPosverh().x + truba.getVerh().getWidth()){
                truba.reposition(truba.getPosverh().x + ((Truba.TRUBAWID+SPACE)*COUNT));
            }

            if (truba.collides(bird.getBbird()))
                gsm.set(new Play(gsm));
        }
        camera.update();

    }

    @java.lang.Override
    public void render(SpriteBatch sb) {
        sb.setProjectionMatrix(camera.combined);
        sb.begin();
        sb.draw(background, camera.position.x - (camera.viewportWidth/2),0);
        sb.draw(bird.getBird(), bird.getPosit().x, bird.getPosit().y);
        for(Truba truba: trubi) {
            sb.draw(truba.getVerh(), truba.getPosniz().x, truba.getPosverh().y);
            sb.draw(truba.getNiz(), truba.getPosniz().x, truba.getPosniz().y);
        }
        sb.end();


    }

    @java.lang.Override
    public void dispose() {


    }
}
